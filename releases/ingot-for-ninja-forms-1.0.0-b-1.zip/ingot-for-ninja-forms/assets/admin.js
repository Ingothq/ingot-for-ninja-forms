ingotApp.controller( 'nfforms', [ '$scope', function ( $scope ) {
    var forms = INGOT_FORM_NF.forms;
    $scope.forms = forms;
} ] );
